package com.example.JwtRegister;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtRegisterApplicationTests {

	@Test
	void contextLoads() {
	}

}
