package com.example.JwtRegister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtRegisterApplication.class, args);
	}

}
