package com.example.EmailOtpVerification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailOtpVerificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
