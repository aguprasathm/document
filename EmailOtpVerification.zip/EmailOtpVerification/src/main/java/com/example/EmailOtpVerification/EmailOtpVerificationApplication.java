package com.example.EmailOtpVerification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailOtpVerificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailOtpVerificationApplication.class, args);
	}

}
