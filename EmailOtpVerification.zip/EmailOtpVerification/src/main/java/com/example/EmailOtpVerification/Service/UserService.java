package com.example.EmailOtpVerification.Service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.EmailOtpVerification.Dto.RequestDto;
import com.example.EmailOtpVerification.Dto.ResponseDto;
import com.example.EmailOtpVerification.Entity.User;
import com.example.EmailOtpVerification.UserRepository.UserRepo;

@Service
public class UserService {
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	EmailService emailService;
	public ResponseDto registerUser(RequestDto request) {
	    ResponseDto res = new ResponseDto();
	    
	    User existingUser = this.userRepo.findByEmail(request.getEmail());
	    if (existingUser != null) {
	        res.setMessage("User already registered.");
	    } else {
	        Random r = new Random();
	        String otp = String.format("%06d", r.nextInt(100000));
	        User newUser = new User();
	        newUser.setUsername(request.getUsername());
	        newUser.setEmail(request.getEmail());
	        newUser.setOtp(otp);
	        newUser.setVerified(false);
	        
	        User savedUser = this.userRepo.save(newUser);
	        String subject = "Email Verification";
	        String body = "Your verification OTP is " + savedUser.getOtp();
	        
	        // Email Send
	        this.emailService.sendEMail(savedUser.getEmail(), subject, body);
	        
	        res.setId(savedUser.getId());
	        res.setUsername(savedUser.getUsername());
	        res.setEmail(savedUser.getEmail());
	        res.setMessage("OTP sent successfully!");
	    }
	    return res;
	}

	public String verifyUser(String email, String otp) {
	    String response = "";
	    User user = this.userRepo.findByEmail(email);
	    if (user != null && user.isVerified()) {
	        response = "User is already verified.";
	    } else if (otp.equals(user.getOtp())) {
	        user.setVerified(true);
	        this.userRepo.save(user);
	        response = "User verified successfully.";
	    } else {
	        response = "User not verified.";
	    }
	    return response;
	}

//	
//	
//	public ResponseDto registerUser(RequestDto request) {
//	    ResponseDto res = new ResponseDto();
//
//	    User existingUser = this.userRepo.findByEmail(request.getEmail());
//	    if (existingUser != null) {
//	        res.setMessage("User already registered.");
//	    } else {
//	        User newUser = new User();
//	        newUser.setUsername(request.getUsername());
//	        newUser.setEmail(request.getEmail());
//	        newUser.setVerified(true); // Assuming the user is considered verified upon registration
//
//	        User savedUser = this.userRepo.save(newUser);
//
//	        String subject = "Registration Successful";
//	        String body = "Thank you for registering with us!";
//
//	        // Email Send (Assuming your EmailService handles the email sending logic)
//	        this.EmailService.sendEMail(savedUser.getEmail(), subject, body);
//
//	        res.setId(savedUser.getId());
//	        res.setUsername(savedUser.getUsername());
//	        res.setEmail(savedUser.getEmail());
//	        res.setMessage("Registration successful! Welcome to our platform.");
//	    }
//	    return res;
//	}
//
//	
	
	
	
	
	
}
